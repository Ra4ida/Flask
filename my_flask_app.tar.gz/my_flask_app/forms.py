from flask_wtf import FlaskForm
from wtforms import StringField, DateField, FloatField, SelectField, FileField, SubmitField, PasswordField, BooleanField, TextAreaField
from wtforms.validators import DataRequired, Length, NumberRange, ValidationError, Regexp, EqualTo, Optional
from datetime import datetime
import os

class AuthorForm(FlaskForm):
    name = StringField('Author Name', validators=[
        DataRequired(message="❗ Author name is required."),
        Length(min=2, max=100, message="❗ Author name must be between 2 and 100 characters."),
        Regexp(r'^[A-Za-z\s]+$', message="❗ Author name must contain only letters and spaces.")
    ])
    biography = TextAreaField('Biography', validators=[
        Optional(),
        Length(max=500, message="❗ Biography must be less than 500 characters.")
    ])
    image = FileField('Author Image', validators=[
        Optional()
    ])
    submit = SubmitField('Add Author')

class EditAuthorForm(FlaskForm):
    name = StringField('Author Name', validators=[
        DataRequired(message="❗ Author name is required."),
        Length(min=2, max=100, message="❗ Author name must be between 2 and 100 characters."),
        Regexp(r'^[A-Za-z\s]+$', message="❗ Author name must contain only letters and spaces.")
    ])
    biography = TextAreaField('Biography', validators=[
        Optional(),
        Length(max=500, message="❗ Biography must be less than 500 characters.")
    ])
    image = FileField('Author Image', validators=[
        Optional()
    ])
    submit = SubmitField('Update Author')

class BookForm(FlaskForm):
    name = StringField('Book Name', validators=[
        DataRequired(message="❗ Book name is required."),
        Length(min=2, max=200, message="❗ Book name must be between 2 and 200 characters."),
        Regexp(r'^[A-Za-z\s]+$', message="❗ Book name must contain only letters and spaces.")
    ])
    publish_date = DateField('Publish Date', format='%Y-%m-%d', validators=[
        DataRequired(message="❗ Publish date is required.")
    ])
    price = FloatField('Price', validators=[
        DataRequired(message="❗ Price is required."),
        NumberRange(min=0, message="❗ Price must be a positive number.")
    ])
    appropriate_age = SelectField('Appropriate Age', choices=[
        ('Under 8', 'Under 8'),
        ('8-15', '8-15'),
        ('Adults', 'Adults')
    ], validators=[
        DataRequired(message="❗ Appropriate age is required.")
    ])
    author_id = SelectField('Author', coerce=int, validators=[
        DataRequired(message="❗ Author is required.")
    ])
    image = FileField('Book Image', validators=[
        DataRequired(message="❗ Book image is required.")
    ])
    submit = SubmitField('Add Book')

    def validate_publish_date(self, field):
        if field.data > datetime.today().date():
            raise ValidationError("❗ Publish date cannot be in the future.")

class EditBookForm(FlaskForm):
    name = StringField('Book Name', validators=[
        DataRequired(message="❗ Book name is required."),
        Length(min=2, max=200, message="❗ Book name must be between 2 and 200 characters."),
        Regexp(r'^[A-Za-z\s]+$', message="❗ Book name must contain only letters and spaces.")
    ])
    publish_date = DateField('Publish Date', format='%Y-%m-%d', validators=[
        DataRequired(message="❗ Publish date is required.")
    ])
    price = FloatField('Price', validators=[
        DataRequired(message="❗ Price is required."),
        NumberRange(min=0, message="❗ Price must be a positive number.")
    ])
    appropriate_age = SelectField('Appropriate Age', choices=[
        ('Under 8', 'Under 8'),
        ('8-15', '8-15'),
        ('Adults', 'Adults')
    ], validators=[
        DataRequired(message="❗ Appropriate age is required.")
    ])
    author_id = SelectField('Author', coerce=int, validators=[
        DataRequired(message="❗ Author is required.")
    ])
    image = FileField('Book Image', validators=[
        Optional()
    ])
    submit = SubmitField('Update Book')

    def validate_publish_date(self, field):
        if field.data > datetime.today().date():
            raise ValidationError("❗ Publish date cannot be in the future.")

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[
        DataRequired(message="❗ Username is required.")
    ])
    password = PasswordField('Password', validators=[
        DataRequired(message="❗ Password is required.")
    ])
    submit = SubmitField('Login')

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[
        DataRequired(message="❗ Username is required."),
        Length(min=2, max=80, message="❗ Username must be between 2 and 80 characters.")
    ])
    password = PasswordField('Password', validators=[
        DataRequired(message="❗ Password is required."),
        Length(min=6, message="❗ Password must be at least 6 characters.")
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(message="❗ Please confirm your password."),
        EqualTo('password', message="❗ Passwords must match.")
    ])
    is_admin = BooleanField('Register as Admin')  
    submit = SubmitField('Register')